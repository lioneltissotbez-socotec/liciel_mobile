window.store = {
  mission: null,
  ui: {
    screen: "start"
  }
};
